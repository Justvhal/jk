# ZeistMangaV6
ZeistManga v6 adalah tema manga premium dengan harga terjangkau.

Tema ini tidak dijual atau dibagikan gratis. Harga yang dipatok adalah donasi untuk pemeliharaan, update dan support.

Desainnya mengusung lebih modern, Dev menikmati proses membuatnya karena tidak mengikuti desain clone, ya bisa dibilang ini karya original yang inspirasinya diambil dari berbagai situs web. Developer EmissionHex ingin desainnya bebas gangguan, langsung ke intinya, minimalistic dan tanpa basa basi.

Tema ini bukan pengganti ZeistManga v5, tapi alternative dengan desain berbeda. Seluruh codenya dibangun dari awal bukan hasil copy paste dari tema sebelumnya.

## What New
- Versi update meta header untuk SEO
- Peningkatan peforma
- Optimisasi code SEO
- Chapter Index

## Mode
1. Normal Mode
2. Mode without post Series

## Chapter and volume label format
Ch 24 Vol 3
or
Ch 1 Vol 1

## Label Wajib
Main Category: Series/Chapter
Status: Completed,Ongoing,Dropped,Hiatus
Tipe: Manga,Manhua,Manhwa,Doujin,LN,WN
Rating: Ecchi,Gore,NSFW
Genre: Action,Adventure...
Score: 1.0,2.0,3.4,9.7, etc

## Credit
1. Advance label filter: https://www.rasgane.com/2023/06/labels-in-blogger.html
2. Bookmark Igniel: https://www.igniel.com/2022/12/widget-bookmark-blog.html
3. Chapter vol filter https://datakodehiru.blogspot.com/2023/07/atasi-max-label-di-chapter-postpada.html
4. owlCarousel2 Yukinee
5. Manga List by VuTran

## Youtube
- Memindahkan lokasi notifikasi
- Memilih versi related post (Costumization)
- Memilih warna complementry (Costumization)
